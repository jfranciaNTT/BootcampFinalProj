package com.nttdata.ministerio_educacao;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class MinisterioEducacaoApplicationTests {

	@Test
	void contextLoads() {
	}

}
