package com.nttdata.ministerio_educacao.repository;

import com.nttdata.ministerio_educacao.model.Disciplina;
import org.springframework.data.jpa.repository.JpaRepository;

public interface DisciplinaRepository extends JpaRepository<Disciplina, Long> {
}
